#!/usr/bin/python

#Get necessary dependancies
import matplotlib
matplotlib.use('Agg')
from matplotlib import pyplot as plt
import numpy as np
import re
import os

#Create list to hold each different possible graph items
dateTime = []
protocol = []
senderIp = []
destPort = []

#Initial variables
rtspcount = 0
telnetcount = 0
webcount = 0
rtsp = "RTSP "
telnet = "Telnet "
http = "Web "

# List to hold all logfile names
lognames = []

#Loop through current directory, and find all log files
for file in os.listdir('.'):
    if file.startswith("honeypy.log"):
        lognames.append(file)

#Loop through all the logfiles found in the current directory
for file in lognames:
    # Opening the current logfile in loop
    logfile = open(file, "r")

    #Loop through each line from the logfile
    for line in logfile:
        #Group each logfile line found
        regex = r"(\d*-\d*-\d*\s\d*:\d*:\d*)(?:.*]\s[^A-Z]*)(\w*\s)(\w*\s)(\d*.\d*.\d*.\d*\s)(\d*\s)(\w*\s)(\d*.\d*.\d*.\d*\s)(\d*)(?:.*)"
        #Check for matching regex in the current line of logfile
        linematch = re.match(regex, line)
        #Ensure only matched honeypy logs are found
        if linematch:
            #Removes dupe entries of time, and add items to their approriate lists
            if linematch.group(1) not in dateTime:
                dateTime.append(linematch.group(1))
                protocol.append(linematch.group(6))
                senderIp.append(linematch.group(7))
                destPort.append(linematch.group(5))
                
#For every logged result, get the requests for each appropriate protocol
rtspcount = protocol.count(rtsp)
webcount = protocol.count(http)
telnetcount = protocol.count(telnet)

#Print total number of requests for IP camera honeypot
totalreqs = len(destPort)
print totalreqs

#Select the x-axis ports
ports = (rtsp, telnet, http)
#Get the number of requests for each port (Y-axis)
numberofattempts = [rtspcount,telnetcount,webcount]
#Create array to represent the number of different ports
y_pos = np.arange(len(ports))

#Create the graphs for the number of total connection attempts by port
plt.bar(y_pos, numberofattempts, align='center', alpha=0.7)
plt.xticks(y_pos, ports)
plt.ylabel('Number of connection attempts')
plt.xlabel('Emulated ports')
plt.title('Chart of IP camera honeypot attempts')
#Export graph results to png file
plt.savefig("honeypot_port_results.png")

logfile.close()
