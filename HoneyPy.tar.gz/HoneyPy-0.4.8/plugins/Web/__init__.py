# Copyright (c) 2015 foospidy
# https://github.com/foospidy/HoneyPy
# See LICENSE for details

from Web import pluginFactory
