#### Description
Answers dns queries with a random ip address. For cname queries it is a static response. Responds to versionbind queries with an old and unpatched version.

#### Dependencies
This plugin requires dnslib (https://pypi.python.org/pypi/dnslib).
run: pip install dnslib
